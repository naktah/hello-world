<?php

use App\Http\Controllers\CavityController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\LotController;
use App\Http\Controllers\ModelController;
use App\Http\Controllers\MoldCodeController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});



//---Lot Maintenance Routes--//
Route::resource('/lot', LotController::class);
Route::resource('/moldcode', MoldCodeController::class);
Route::post('/getCavity', [MoldCodeController::class, 'getCavity'])->name('getCavity');
Route::resource('/model', ModelController::class);
Route::resource('/cavity', CavityController::class);

// Route::get('/lot', [LotController::class, 'index'])->name('lot.index');