<!-- Modal -->
<div class="modal fade" id="createnewlotmodal" tabindex="-1" role="dialog" aria-labelledby="createnewlotmodalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="createnewlotmodalLabel">Create Lot Information</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
            <form>
                <div class="row">
                    <div class="col">
                        <label for="machineCode">Machine Name</label>
                        <select id="machineCode" class="form-control">
                          <?php $__currentLoopData = $machine; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($value); ?>" <?php echo e(( $key == $selectedMachineID) ? 'selected' : ''); ?>> 
                            <?php echo e($value); ?> 
                            </option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                        </select>
                    </div>
                    <div class="col">
                        <label for="moldCode">Mold Code</label>
                        <select id="moldCode" class="form-control">
                        <option selected>Choose...</option>
                        <option>...</option>
                        </select>
                    </div>
                    <div class="col">
                        <label for="model">Model</label>
                        <select id="model" class="form-control">
                          <option></option>
                          
                        </select>
                    </div>
                </div>
                <div class="row">
                   <div class="col">
                    <label for="ingotlot">Ingot Lot</label>
                    <input type="text" name="ingotlot" class="form-control" id="ingot_lot" aria-describedby="ingotlot">
                   </div>
                  <div class="col">
                    <label for="moldShots">Mold Shots</label>
                    <input type="text" name="moldShots" class="form-control" id="mold_shots" aria-describedby="moldShots" readonly>
                  </div>
                </div>
                <div class="row">
                  <div class="col">
                    <label for="model">Tray Size</label>
                    <input type="text" name="traySize" class="form-control" id="tray_size" aria-describedby="traySize" readonly>
                  </div>
                  <div class="col">
                    <label for="cavity1">Cavity 1</label>
                    <input type="text" name="cavity1" class="form-control" id="cavity1" aria-describedby="cavity1" readonly>
                  </div>
                  <div class="col">
                    <label for="cavity2">Cavity 2</label>
                    <input type="text" name="cavity2" class="form-control" id="cavity2" aria-describedby="cavity2" readonly>
                  </div>
                </div>
                <div class="row">
                  <div class="col">
                    <label for="cavity3">Cavity 3</label>
                    <input type="text" name="cavity3" class="form-control" id="cavity3" aria-describedby="cavity3" readonly>
                  </div>
                  <div class="col">
                    <label for="cavity4">Cavity 4</label>
                    <input type="cavity4" name="cavity4 " class="form-control" id="cavity4" aria-describedby="cavity4" readonly>
                  </div>
                </div>
              </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Save changes</button>
        </div>
      </div>
    </div>
  </div><?php /**PATH C:\Users\Enduser\Documents\laravel projects\BPTS-repo\BPTSlaravel8\resources\views/modals/createnewlot.blade.php ENDPATH**/ ?>