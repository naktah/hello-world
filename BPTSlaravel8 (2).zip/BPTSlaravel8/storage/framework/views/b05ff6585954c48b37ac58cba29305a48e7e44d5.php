<!-- Modal -->
<div class="modal fade" id="createnewlotmodal" tabindex="-1" role="dialog" aria-labelledby="createnewlotmodalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="createnewlotmodalLabel">Create Mold Code</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
            <form action="" method="POST">
              <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col">
                        <label for="moldCode">Mold Code</label>
                        <input type="text" name="mold_code" class="form-control" id="moldCode" aria-describedby="moldCode">
                    </div>
                    <div class="col">
                        <label for="model">Mold Type</label>
                        <select id="model" name="model" class="form-control">
                          <?php $__currentLoopData = $model; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($value); ?>" <?php echo e(( $key == $selectedModelID) ? 'selected' : ''); ?>> 
                            <?php echo e($value); ?> 
                            </option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                        </select>
                    </div>    
                </div>
                <div class="row">
                  <div class="col">
                    <label for="moldShots">Mold Shots</label>
                    <input type="text" name="mold_shots" class="form-control" id="moldShots" aria-describedby="moldShots">
                  </div>
                  
                </div>
              
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Save changes</button>
        </div>
      </form>
      </div>
    </div>
  </div>
  <script type="text/javascript">
    // CSRF Token
    var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
    $(document).ready(function(){
 
      $( "#cavity1" ).select2({
         ajax: { 
           url: "<?php echo e(route('getCavity')); ?>",
           type: "post",
           dataType: 'json',
           delay: 250,
           data: function (params) {
             return {
                _token: CSRF_TOKEN,
                search: params.term // search term
             };
           },
           processResults: function (response) {
             return {
               results: response
             };
           },
           cache: true
         }
 
      });
 
    });
    </script>
    <script type="text/javascript">
      // CSRF Token
      var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
      $(document).ready(function(){
   
        $( "#cavity2" ).select2({
           ajax: { 
             url: "<?php echo e(route('getCavity')); ?>",
             type: "post",
             dataType: 'json',
             delay: 250,
             data: function (params) {
               return {
                  _token: CSRF_TOKEN,
                  search: params.term // search term
               };
             },
             processResults: function (response) {
               return {
                 results: response
               };
             },
             cache: true
           }
   
        });
   
      });
      </script>
      <script type="text/javascript">
        // CSRF Token
        var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
        $(document).ready(function(){
     
          $( "#cavity3" ).select2({
             ajax: { 
               url: "<?php echo e(route('getCavity')); ?>",
               type: "post",
               dataType: 'json',
               delay: 250,
               data: function (params) {
                 return {
                    _token: CSRF_TOKEN,
                    search: params.term // search term
                 };
               },
               processResults: function (response) {
                 return {
                   results: response
                 };
               },
               cache: true
             }
     
          });
     
        });
        </script>
         <script type="text/javascript">
          // CSRF Token
          var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
          $(document).ready(function(){
       
            $( "#cavity4" ).select2({
               ajax: { 
                 url: "<?php echo e(route('getCavity')); ?>",
                 type: "post",
                 dataType: 'json',
                 delay: 250,
                 data: function (params) {
                   return {
                      _token: CSRF_TOKEN,
                      search: params.term // search term
                   };
                 },
                 processResults: function (response) {
                   return {
                     results: response
                   };
                 },
                 cache: true
               }
       
            });
       
          });
          </script>
        
        <?php /**PATH C:\Users\Enduser\Documents\laravel projects\BPTS-repo\BPTSlaravel8\resources\views/modals/createnewmoldcode.blade.php ENDPATH**/ ?>