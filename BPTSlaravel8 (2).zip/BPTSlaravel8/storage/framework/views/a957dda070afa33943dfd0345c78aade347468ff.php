<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>

<div class="container-fluid">
    <h1>Lot Creation Maintenance</h1>
    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#createnewlotmodal">Create New Lot</button>
    <?php echo $__env->make('modals.createnewlot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
    <table class="table table-bordered table-hover data-table">
        <thead class="thead-dark">
            <tr>
                <th>Machine Info ID</th>
                <th>Machine Name</th>
                <th>Mold Code</th>
                <th>Model</th>
                <th>Ingot Lot</th>
                <th>Mold Shots</th>
                <th>Tray Size</th>
                <th>Cavity1</th>
                <th>Cavity2</th>
                <th>Cavity3</th>
                <th>Cavity4</th>
                <th>Updated By</th>
                <th>Updated Date</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
        </tbody>
    </table>
</div>
   
</body>
   
<script type="text/javascript">
  $(function () {
    var table = $('.data-table').DataTable({
        responsive: true,
        processing: true,
        serverSide: true,
        ajax: "<?php echo e(route('lot.index')); ?>",
        columns: [
            {data: 'mc_info_id', name: 'mc_info_id'},
            {data: 'machine', name: 'machine'},
            {data: 'mold_code', name: 'mold_code'},
            {data: 'model', name: 'model'},
            {data: 'ingot_lot', name: 'ingot_lot'},
            {data: 'mold_shots', name: 'mold_shots'},
            {data: 'tray_size', name: 'tray_size'},
            {data: 'cavity1', name: 'cavity1'},
            {data: 'cavity2', name: 'cavity2'},
            {data: 'cavity3', name: 'cavity3'},
            {data: 'cavity4', name: 'cavity4'},
            {data: 'updated_by', name: 'updated_by'},
            {data: 'updated_date', name: 'updated_date'},
            {data: 'action', name: 'action', orderable: false, searchable: false},
        ]
    });
    
  });
</script>
</html><?php /**PATH C:\Users\Enduser\Documents\laravel projects\BPTS-repo\BPTSlaravel8\resources\views/lot.blade.php ENDPATH**/ ?>