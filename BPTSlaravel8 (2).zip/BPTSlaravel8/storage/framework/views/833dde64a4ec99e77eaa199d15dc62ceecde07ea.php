<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>

<div class="container-fluid">
    <h1>Mold Code Maintenance</h1>
    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#createnewlotmodal">Create New Mold Code</button>
    <?php echo $__env->make('modals.createnewmoldcode', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
    <table class="table table-bordered table-hover mold-code-data-table">
        <thead class="thead-dark">
            <tr>
                <th>Mold Code ID</th>
                <th>Mold Code</th>
                <th>Mold Type</th>
                <th>Mold Shots</th>
                <th>Updated By</th>
                <th>Updated date</th>
                <th>Active?</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
        </tbody>
    </table>
</div>
   
</body>
   
<script type="text/javascript">
  $(function () {
    var table = $('.mold-code-data-table').DataTable({
        responsive: true,
        processing: true,
        serverSide: true,
        ajax: "<?php echo e(route('moldcode.index')); ?>",
        columns: [
            {data: 'mold_code_id', name: 'mold_code_id'},
            {data: 'mold_code', name: 'mold_code'},
            {data: 'model', name: 'model'},
            {data: 'mold_shots', name: 'mold_shots'},
            {data: 'updated_by', name: 'updated_by'},
            {data: 'update_date', name: 'update_date'},
            {data: 'action', name: 'action', orderable: false, searchable: false},
        ]
    });
    
  });
</script>

</html><?php /**PATH C:\Users\Enduser\Documents\laravel projects\BPTS-repo\BPTSlaravel8\resources\views/moldcode.blade.php ENDPATH**/ ?>