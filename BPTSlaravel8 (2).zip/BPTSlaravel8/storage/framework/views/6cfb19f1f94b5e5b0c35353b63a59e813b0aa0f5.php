<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>

<div class="container-fluid">
    <h1>Model Creation Maintenance</h1>
    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#createnewmodelmodal">Create New Model</button>
    <?php echo $__env->make('modals.createnewmodel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
    <table class="table table-bordered table-hover data-table">
        <thead class="thead-dark">
            <tr>
                <th>Model ID</th>
                <th>Model</th>
                <th>Casting Tray Size</th>
                <th>Machining Tray Size</th>
                <th>Updated By</th>
                <th>Date Updated</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
        </tbody>
    </table>
</div>
   
</body>
   
<script type="text/javascript">
  $(function () {
    var table = $('.data-table').DataTable({
        responsive: true,
        processing: true,
        serverSide: true,
        ajax: "<?php echo e(route('model.index')); ?>",
        columns: [
            {data: 'm_model_id', name: 'm_model_id'},
            {data: 'model', name: 'model'},
            {data: 'tray_size_casting', name: 'tray_size_casting'},
            {data: 'tray_size_machining', name: 'tray_size_machining'},
            {data: 'updated_by', name: 'updated_by'},
            {data: 'updated_at', name: 'updated_at'},
            {data: 'action', name: 'action', orderable: false, searchable: false},
        ]
    });
    
  });
</script>
</html><?php /**PATH C:\Users\Enduser\Documents\laravel projects\BPTS-repo\BPTSlaravel8\resources\views/model.blade.php ENDPATH**/ ?>