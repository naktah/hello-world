@include('header')
<body>

<div class="container-fluid">
    <h1>Cavity Creation Maintenance</h1>
    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#createnewcavitymodal">Create New Cavity</button>
    @include('modals.createnewcavity') 
    <table class="table table-bordered table-hover cavity-data-table">
        <thead class="thead-dark">
            <tr>
                <th>Cavity ID</th>
                <th>Mold Code</th>
                <th>Cavity</th>
                <th>Updated By</th>
                <th>Date Updated</th>
                <th>Active?</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
        </tbody>
    </table>
</div>
   
</body>
   
<script type="text/javascript">
  $(function () {
    var table = $('.cavity-data-table').DataTable({
        responsive: true,
        processing: true,
        serverSide: true,
        ajax: "{{ route('cavity.index') }}",
        columns: [
            {data: 'id', name: 'id'},
            {data: 'mold_code', name: 'mold_code'},
            {data: 'cavity', name: 'cavity'},
            {data: 'updated_by', name: 'updated_by'},
            {data: 'updated_date', name: 'updated_date'},
            {data: 'isactive', name: 'isactive'},
            {data: 'action', name: 'action', orderable: false, searchable: false},
        ]
    });
    
  });
</script>
</html>