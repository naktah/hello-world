<!-- Modal -->
<div class="modal fade" id="createnewmodelmodal" tabindex="-1" role="dialog" aria-labelledby="createnewmodelmodalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="createnewmodelmodalLabel">Create new Model</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
            <form>
                <div class="row">
                    <div class="col">
                        <label for="machineCode">Model Name</label>
                        <select id="machineCode" class="form-control">
                          {{-- @foreach ($model as $key => $value)
                            <option value="{{ $key }}" {{ ( $key == $selectedID) ? 'selected' : '' }}> 
                            {{ $value }} 
                            </option>
                          @endforeach     --}}
                        </select>
                    </div>
                    <div class="col">
                        <label for="moldCode">Casting Tray Size</label>
                        <select id="moldCode" class="form-control">
                        <option selected>Choose...</option>
                        <option>...</option>
                        </select>
                    </div>
                    <div class="col">
                        <label for="model">Machining Tray Size</label>
                        <select id="model" class="form-control">
                          <option></option>
                          {{-- @foreach ($model as $key => $value)
                            <option value="{{ $key }}" {{ ( $key == $selectedID) ? 'selected' : '' }}> 
                            {{ $value }} 
                            </option>
                          @endforeach   --}}
                        </select>
                    </div>
                </div>
              </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Save changes</button>
        </div>
      </div>
    </div>
  </div>