<!-- Modal -->
<div class="modal fade" id="createnewcavitymodal" tabindex="-1" role="dialog" aria-labelledby="createnewcavitymodalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="createnewcavitymodalLabel">Create new Cavity</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
            <form>
                <div class="row">
                    <div class="col">
                        <label for="moldCode">Mold</label>
                        <select id="moldCode" name="mold_code" class="form-control">
                          @foreach ($model as $key => $value)
                            <option value="{{ $value }}" {{ ( $key == $selectedModelID) ? 'selected' : '' }}> 
                            {{ $value }} 
                            </option>
                          @endforeach    
                        </select>
                    </div>
                    <div class="col">
                        <label for="cavity">Cavity</label>
                        <input type="text" name="cavity" class="form-control" id="cavity" aria-describedby="cavity">
                    </div>
                    {{-- <div class="col">
                        <label for="model">Machining Tray Size</label>
                        <select id="model" class="form-control">
                          <option></option>
                          @foreach ($model as $key => $value)
                            <option value="{{ $key }}" {{ ( $key == $selectedID) ? 'selected' : '' }}> 
                            {{ $value }} 
                            </option>
                          @endforeach  
                        </select>
                    </div> --}}
                </div>
              </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Save changes</button>
        </div>
      </div>
    </div>
  </div>