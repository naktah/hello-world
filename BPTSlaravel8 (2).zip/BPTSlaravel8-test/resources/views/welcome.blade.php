{{-- @include('header')
<body class="antialiased">
        <div class="relative flex items-top justify-center min-h-screen bg-gray-100 dark:bg-gray-900 sm:items-center py-4 sm:pt-0">
            <select class="js-example-basic-single" >
                <option></option>
              </select>
        </div>
    </body>
    <script>
        // $(document).ready(function() {
        // $('.js-example-basic-single').select2();
        // });
        $('.js-data-example-ajax').select2({
        ajax: "{{ route('cavity.index') }}",
        columns:[
            {data: 'cavity', name: 'cavity'},
        ]
});
    </script>
</html> --}}
