
<?php /**PATH C:\Users\Enduser\Documents\laravel projects\BPTS-repo\BPTSlaravel8-test\resources\views/welcome.blade.php ENDPATH**/ ?>