<!-- Modal -->
<div class="modal fade" id="createnewlotmodal" tabindex="-1" role="dialog" aria-labelledby="createnewlotmodalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="createnewlotmodalLabel">Create Lot Information</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
            <form>
                <div class="row">
                    <div class="col">
                        <label for="inputState">Machine Code</label>
                        <select id="inputState" class="form-control">
                        <option selected>Choose...</option>
                        <option>...</option>
                        </select>
                    </div>
                    <div class="col">
                        <label for="inputState">Mold Code</label>
                        <select id="inputState" class="form-control">
                        <option selected>Choose...</option>
                        <option>...</option>
                        </select>
                    </div>
                    <div class="col">
                        <label for="inputState">Model</label>
                        <select id="inputState" class="form-control">
                        <option selected>Choose...</option>
                        <option>...</option>
                        </select>
                    </div>
                </div>
              </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary">Save changes</button>
        </div>
      </div>
    </div>
  </div><?php /**PATH C:\Users\Enduser\Documents\laravel projects\BPTS-repo\BPTSlaravel8\resources\views/modals/createnewlot.blade.php ENDPATH**/ ?>